package vaccinesystem;

public class VaccineSystem {

    public static void main(String[] args) {
        HomePageForm hpf = new HomePageForm();
        hpf.setVisible(true);
    }
}
